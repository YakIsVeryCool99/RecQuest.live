﻿using System;
using System.Collections.Generic;
using System.Text;

namespace api
{
    class Avatar
    {
		public string OutfitSelections { get; set; }
		public string HairColor { get; set; }
		public string SkinColor { get; set; }
		public string FaceFeatures { get; set; }
	}
}
