﻿using System;

namespace api2018
{
	// Token: 0x02000036 RID: 54
	public class mPlayerReputation
	{
		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000179 RID: 377 RVA: 0x00002AF5 File Offset: 0x00000CF5
		// (set) Token: 0x0600017A RID: 378 RVA: 0x00002AFD File Offset: 0x00000CFD
		public int Noteriety { get; set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600017B RID: 379 RVA: 0x00002B06 File Offset: 0x00000D06
		// (set) Token: 0x0600017C RID: 380 RVA: 0x00002B0E File Offset: 0x00000D0E
		public int CheerGeneral { get; set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600017D RID: 381 RVA: 0x00002B17 File Offset: 0x00000D17
		// (set) Token: 0x0600017E RID: 382 RVA: 0x00002B1F File Offset: 0x00000D1F
		public int CheerHelpful { get; set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x0600017F RID: 383 RVA: 0x00002B28 File Offset: 0x00000D28
		// (set) Token: 0x06000180 RID: 384 RVA: 0x00002B30 File Offset: 0x00000D30
		public int CheerGreatHost { get; set; }

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000181 RID: 385 RVA: 0x00002B39 File Offset: 0x00000D39
		// (set) Token: 0x06000182 RID: 386 RVA: 0x00002B41 File Offset: 0x00000D41
		public int CheerSportsman { get; set; }

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000183 RID: 387 RVA: 0x00002B4A File Offset: 0x00000D4A
		// (set) Token: 0x06000184 RID: 388 RVA: 0x00002B52 File Offset: 0x00000D52
		public int CheerCreative { get; set; }

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000185 RID: 389 RVA: 0x00002B5B File Offset: 0x00000D5B
		// (set) Token: 0x06000186 RID: 390 RVA: 0x00002B63 File Offset: 0x00000D63
		public int CheerCredit { get; set; }

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000187 RID: 391 RVA: 0x00002B6C File Offset: 0x00000D6C
		// (set) Token: 0x06000188 RID: 392 RVA: 0x00002B74 File Offset: 0x00000D74
		public int SubscriberCount { get; set; }

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000189 RID: 393 RVA: 0x00002B7D File Offset: 0x00000D7D
		// (set) Token: 0x0600018A RID: 394 RVA: 0x00002B85 File Offset: 0x00000D85
		public int SubscribedCount { get; set; }

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600018B RID: 395 RVA: 0x00002B8E File Offset: 0x00000D8E
		// (set) Token: 0x0600018C RID: 396 RVA: 0x00002B96 File Offset: 0x00000D96
		public int SelectedCheer { get; set; }
	}
}
