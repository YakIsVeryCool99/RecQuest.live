# Welcome to OpenRec!
---
OpenRec is a RecRoom server software made by recroom2016!

### Branches
 - Master / main
 - Nightly

The master branch is the public branch where all the latest updates are published.
The nightly branch is where all the experimental updates that are needed to be tested before release are.

---

### Getting in contact with the community

If you are new to this we recommend you joining our Discord!
Link: https://discord.com/invite/daC8QUhnFP
