﻿using System;

namespace api
{
	// Token: 0x02000019 RID: 25
	internal class ConfigTableEntry
	{
		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600007A RID: 122 RVA: 0x00002336 File Offset: 0x00000536
		// (set) Token: 0x0600007B RID: 123 RVA: 0x0000233E File Offset: 0x0000053E
		public string Key { get; set; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600007C RID: 124 RVA: 0x00002347 File Offset: 0x00000547
		// (set) Token: 0x0600007D RID: 125 RVA: 0x0000234F File Offset: 0x0000054F
		public string Value { get; set; }
	}
}