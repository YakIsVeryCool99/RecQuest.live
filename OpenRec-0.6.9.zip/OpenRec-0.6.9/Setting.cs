﻿using System;

namespace api
{
	// Token: 0x0200003D RID: 61
	internal class Setting
	{
		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060001C8 RID: 456 RVA: 0x00002D5B File Offset: 0x00000F5B
		// (set) Token: 0x060001C9 RID: 457 RVA: 0x00002D63 File Offset: 0x00000F63
		public string Key { get; set; }

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060001CA RID: 458 RVA: 0x00002D6C File Offset: 0x00000F6C
		// (set) Token: 0x060001CB RID: 459 RVA: 0x00002D74 File Offset: 0x00000F74
		public string Value { get; set; }
	}
}