﻿using System;

namespace api2018
{
	// Token: 0x02000037 RID: 55
	public class mPlatformID
	{
		// Token: 0x17000097 RID: 151
		// (get) Token: 0x0600018E RID: 398 RVA: 0x00002B9F File Offset: 0x00000D9F
		// (set) Token: 0x0600018F RID: 399 RVA: 0x00002BA7 File Offset: 0x00000DA7
		public int Platform { get; set; }

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000190 RID: 400 RVA: 0x00002BB0 File Offset: 0x00000DB0
		// (set) Token: 0x06000191 RID: 401 RVA: 0x00002BB8 File Offset: 0x00000DB8
		public ulong PlatformId { get; set; }
	}
}
